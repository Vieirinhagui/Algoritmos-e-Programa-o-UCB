#include <stdio.h>
#include <string.h>

main()
{
    char str[20];

    printf("Digite uma string: ");
    gets(str);

    printf("A string digitada foi: ");
    puts(str);
}
